from selenium import webdriver
from selenium.webdriver.common.by import By


urls = {
        "XAU/USD":"https://www.investing.com/currencies/xau-usd-historical-data",
        "XAU/EUR":"https://www.investing.com/currencies/xau-eur-historical-data",
        "XAU/BTC":"https://www.investing.com/currencies/xau-btc-historical-data"
}


def get_price(link):
        driver = webdriver.Chrome()
        driver.get(link)

        price_element = driver.find_elements(By.CLASS_NAME,"historical-data-v2_price__atUfP")
        price = price_element[0].text.replace(' ','##')
        print(price)
        driver.quit()
        return price

prices={}
for currency, link in urls.items():
    prices[currency] = get_price(link)


with open('gold_price.txt', 'w') as file:
    for currency, price in prices.items():
        if price:
            file.write(f"{currency}##{price}\n")



print("ok")




